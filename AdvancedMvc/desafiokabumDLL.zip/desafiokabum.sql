-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 22/04/2025 às 14:38
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `desafiokabum`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `clientes`
--

CREATE TABLE `clientes` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `data_nascimento` date NOT NULL,
  `cpf` varchar(14) NOT NULL,
  `rg` varchar(13) NOT NULL,
  `telefone` varchar(17) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `clientes`
--

INSERT INTO `clientes` (`id`, `nome`, `data_nascimento`, `cpf`, `rg`, `telefone`) VALUES
(1, 'pedro', '2025-04-01', '083.974.196-08', '42.848.562', '+55(34)99833-514'),
(3, 'ze', '2025-04-03', '083.974.196-09', '42.848.563', '+55(34)99833-514'),
(6, 'abc', '2025-03-31', '11111111111111', '222222222222', '3333333333333333'),
(13, 'pedro', '2025-04-22', '12312312313', '12312312312', '1111111111111111'),
(14, 'rafa', '2025-04-26', '12312311111111', '123123111111', '1231321312321321'),
(15, 'Cinthia Carvalho', '2004-01-21', '111.111.111-11', '42.848.562-1', '+55(34)99833-5141'),
(16, 'a', '2025-04-02', '083.974.196-01', '42.848.561', '+55(34)9983-35141'),
(17, 'Henrique Fonseca Campos Costa', '2025-04-21', '083.974.196-00', '42.848.562-9', '+55(34)9983-35141'),
(18, 'ana', '2025-04-23', '000.111.222-33', '123123132123', '+12(34)5678-9123'),
(19, 'pedero', '2025-04-18', '999.999.999-99', '999999999999', '+99(99)9999-99999');

-- --------------------------------------------------------

--
-- Estrutura para tabela `enderecos`
--

CREATE TABLE `enderecos` (
  `id` int(11) NOT NULL,
  `estado` varchar(100) NOT NULL,
  `cidade` varchar(100) NOT NULL,
  `bairro` varchar(50) NOT NULL,
  `logradouro` varchar(255) NOT NULL,
  `numero` varchar(20) NOT NULL,
  `complemento` varchar(255) DEFAULT NULL,
  `cep` varchar(20) NOT NULL,
  `cliente_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `enderecos`
--

INSERT INTO `enderecos` (`id`, `estado`, `cidade`, `bairro`, `logradouro`, `numero`, `complemento`, `cep`, `cliente_id`) VALUES
(1, 'MT', 'berarba', 'aaaa', 'PPP', '100', 'Apto 100', '38400-016', 1),
(2, 'MG', 'Patos de Minas', '', 'Praça Cícero Macedo', '63', 'Apto 600', '38400-216', 1),
(3, 'MG', 'Patos de Minas', '', 'Praça Cícero Macedo', '63', 'Apto 600', '38400-216', 1),
(4, 'MT', 'berarba', 'aaaa', 'PPP', '100', 'Apto 100', '38400-016', 1),
(5, 'MG', 'Patos de Minas', '', 'Praça Cícero Macedo', '63', 'Apto 600', '38400-216', 3),
(6, 'MG', 'Patos de Minas', 'Fundinho', 'Praça Cícero Macedo', '63', 'Apto 600', '38400-216', 14);

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `criado_em` datetime DEFAULT current_timestamp(),
  `session_id` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `email`, `senha`, `criado_em`, `session_id`) VALUES
(2, 'Henrique Fonseca Campos Costa', 'henriquefcampos2004@gmail.com', '$2y$10$URBEYIeJzn37q8U.DtIYHuNJ0CVsB3HW.yWiFXyUD45bs.Bb5c0KW', '2025-04-20 01:01:08', 'bvi4eptci0mktut2dl2dgqggnm'),
(3, 'lucas', 'lucas@lucas', '$2y$10$2orbo2vQ5oeq3tzekNCtBOo6U.eoKdDV1ydYjEkLNJjB.YgSw2IUC', '2025-04-20 01:53:51', 'ddubtkel6gun7fnojih3n6rf8f'),
(4, 'joaa', 'joao@joao', '$2y$10$HItaUpLu6qqiwjrfJ3.DPOjjJeGlhffPDq4ZohcjRuuNYvVV7YBbC', '2025-04-20 09:29:54', 'kbsjm6sedt87ug5mqpl6nmdfip'),
(5, 'anderson', 'anderson@anderson', '$2y$10$Qr4JrPzvGkH1XAminpW0aOEzD8wv/0buWdXU.i4sqPhfbSH87/N5y', '2025-04-20 09:41:30', NULL),
(6, 'pedro', 'pedro@pedro', '$2y$10$bbkJwUmtqEI1/Kq5ivIZJe0ct2GDogAvq6hKnyTP3Cfo7p35/hChq', '2025-04-20 09:42:05', NULL),
(7, 'maria', 'maria@maria', '$2y$10$LR6OjfeIhWU.AFJyZVK0MuLfmZjALEutaQ8Jow0mf5m4hFltcphCG', '2025-04-20 09:42:31', NULL),
(8, 'ana', 'ana@ana', '$2y$10$7Tgyh2IAgeB3HXq9v7y8Ye9y4ulFgYapdsiu9lfnvqzHceHbM0DCu', '2025-04-20 09:45:20', NULL),
(9, 'cinthia', 'cinthiaptu15@gmail.com', '$2y$10$pqPEoJU6KUzH4gqIGZVAAOvQg.cCEz4VBhJ8QCA/o9fw4Bg9M1RXm', '2025-04-21 19:19:45', NULL),
(10, 'joao', 'j@j', '$2y$10$cCkCMigDx.tuLTCoJxQpTOXPrlKlqetl9aMtTyEOWQ14kcPzqx9X6', '2025-04-21 19:38:04', NULL),
(11, 'joaozim', 'jj@jj', '$2y$10$efuDbrAQPiVzPhrmgBh2HeSPnPUO35iiy6VFAO4Rh6QQ0wlgRmB56', '2025-04-21 19:40:09', NULL);

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `cpf` (`cpf`),
  ADD UNIQUE KEY `rg` (`rg`);

--
-- Índices de tabela `enderecos`
--
ALTER TABLE `enderecos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_cliente` (`cliente_id`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT de tabela `enderecos`
--
ALTER TABLE `enderecos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `enderecos`
--
ALTER TABLE `enderecos`
  ADD CONSTRAINT `fk_cliente` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
